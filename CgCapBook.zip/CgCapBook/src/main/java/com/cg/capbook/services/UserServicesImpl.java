package com.cg.capbook.services;

import org.springframework.beans.factory.annotation.Autowired;

import com.cg.capbook.beans.User;
import com.cg.capbook.daoservices.UserDAO;

public class UserServicesImpl implements UserServices {
	@Autowired
private UserDAO userDao;
	@Override
	public User createUserAccount(User user) {
		userDao.save(user);
		return user;
	}

	@Override
	public User getUserAccount(User user) {
		return userDao.findById(user.getUserId()).get();
	}

}
