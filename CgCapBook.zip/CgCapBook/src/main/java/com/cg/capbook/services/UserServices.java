package com.cg.capbook.services;

import com.cg.capbook.beans.User;

public interface UserServices {
	User createUserAccount(User user);
	User getUserAccount(User user);

}
